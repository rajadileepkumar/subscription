<?php 
	function subscription_category_add(){
		echo 'Hello World';
	}
?>